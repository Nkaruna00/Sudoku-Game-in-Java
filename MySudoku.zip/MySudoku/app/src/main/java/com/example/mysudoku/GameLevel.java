package com.example.mysudoku;

public enum GameLevel {
    VERY_EASY, EASY, MEDIUM, HARD, EVIL
}